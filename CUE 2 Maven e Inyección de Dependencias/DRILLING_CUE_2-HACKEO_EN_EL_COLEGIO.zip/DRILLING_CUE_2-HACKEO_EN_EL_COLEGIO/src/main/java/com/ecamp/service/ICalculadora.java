package com.ecamp.service;

import java.util.List;

import com.ecamp.model.Alumno;

public interface ICalculadora {
	public List<Alumno> calcularPromedios();

}
